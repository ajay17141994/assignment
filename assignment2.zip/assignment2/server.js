var http = require("http");
var express = require('express');
var app = express();
var mysql      = require('mysql');
var bodyParser = require('body-parser');

//start mysql connection
var connection = mysql.createConnection({
  host     : 'localhost', //mysql database host name
  user     : 'root', //mysql database user name
  password : 'root', //mysql database password
  database : 'agri_bazaar' //mysql database name
});

connection.connect(function(err) {
  if (err) throw err
  console.log('You are now connected...')
})
//end mysql connection

//start body-parser configuration
app.use( bodyParser.json() );       // to support JSON-encoded bodies
app.use(bodyParser.urlencoded({     // to support URL-encoded bodies
  extended: true
}));
//end body-parser configuration

//create app server
var server = app.listen(4000,  "127.0.0.1", function () {

  var host = server.address().address
  var port = server.address().port

  console.log("Example app listening at http://%s:%s", host, port)

});

//to get country results
app.get('/country', function (req, res) {
   connection.query('select id,name from country', function (error, results, fields) {
	  if (error) throw error;
	  res.end(JSON.stringify(results));
	});
});

//to get a single city data
app.get('/city', function (req, res) {
   connection.query('select id,name from city', function (error, results, fields) {
	  if (error) throw error;
	  res.end(JSON.stringify(results));
	});
});

//to get a single state data
app.get('/state', function (req, res) {
   connection.query('select id,name from state', function (error, results, fields) {
	  if (error) throw error;
	  res.end(JSON.stringify(results));
	});
});


//to get all results based on id
app.post('/id', function (req, res) {
  var postData  = req.body;
   connection.query('select * from `registration` WHERE `id`=?', [req.body.id], function (error, results, fields) {
	  if (error) throw error;
	  res.end(JSON.stringify(results));
	});
});

//to get all results based on id
app.post('/edit', function (req, res) {
  var postData  = req.body;
   connection.query('select *, DATE_FORMAT(date(dob),"%d/%m/%Y") as datee from `registration` WHERE `id`=?', [req.body.id], function (error, results, fields) {
	  if (error) throw error;
	  res.end(JSON.stringify(results));
	});
});

//to get all count results based on groupby country condition
app.get('/group', function (req, res) {
   connection.query('select COUNT(id) as count,country from agri_bazaar.registration group by country', function (error, results, fields) {
	  if (error) throw error;
	  res.end(JSON.stringify(results));
	});
});


//to get all results
app.get('/alldata', function (req, res) {
   connection.query('select * from agri_bazaar.registration', function (error, results, fields) {
	  if (error) throw error;
	  res.end(JSON.stringify(results));
	});
});

//to create a new record into mysql database
app.post('/register', function (req, res) {
   var postData  = req.body;
   connection.query('INSERT INTO registration SET ?', postData, function (error, results, fields) {
	  if (error) throw error;
	  res.end(JSON.stringify(results));
	});
});

//to update record into mysql database
app.put('/update', function (req, res) {
   console.log(req.body.name);
   console.log(req.body.password);
  console.log(req.body);
   var postData  = req.body;
   connection.query('UPDATE `registration` SET `name`=?,`password`=? Where `id`=?', [req.body.name,req.body.password,req.body.id], function (error, results, fields) {
	  if (error) throw error;
	  res.end(JSON.stringify(results));
	});
});

