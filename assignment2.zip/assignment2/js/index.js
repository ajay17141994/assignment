var app=angular.module('registrationApp',[])
app.controller('registrationController',function($scope,$http,$filter){
$scope.name = "John Doe";

// fetching all country records
$http.get('http://localhost:4000/country').then(function(data) {
    $scope.country =[];
        angular.forEach(data.data, function (key, value) {                     
            $scope.country.push(key.name);
            // var element = angular.element( document.querySelector( '#countryDrop' ) );
            // element.append(' <option value="'+key.country+'">'+key.country);
        });
    });

// fetching all city records
$http.get('http://localhost:4000/city').then(function(data) {
    $scope.city=[];
    // $scope.city = data;
        angular.forEach(data.data, function (key, value) {
            $scope.city.push(key.name);
            // var element = angular.element( document.querySelector( '#cityDrop' ) );
            // element.append(' <option value="'+key.city+'">'+key.city);        
        });
});

// fetching all state records
$http.get('http://localhost:4000/state').then(function(data) {
    $scope.state=[];
        angular.forEach(data.data, function (key, value) {
            $scope.state.push( key.name);
            // var element = angular.element( document.querySelector( '#stateDrop' ) );
            // element.append(' <option value="'+key.state+'">'+key.state);
        });
});
    
// fetching all  records
 $http.get('http://localhost:4000/alldata')
            .then(function (response) {$scope.feilds = response.data;
});

  
// cheking for id input wheather it is available or not
$scope.chkid=function(){
    if(isNaN(parseInt($scope.id)))
        {
            alert("ID must be number");
             $scope.id="";
        }
        var ids ={ 
            id:$scope.id
        } 
        $http.post('http://localhost:4000/id',ids)
                .then(function(data) {
                    $scope.result = data;
                    if(data.data.length==0)
                    {
                        $scope.info="userid available";
                    }
                    else{
                        $scope.info="userid unavailable";
                    }
                })
}



// fetching all  records based on groupby country condition
$scope.filter=function(){
        $http.get('http://localhost:4000/group')
        .then(function (response)
         {
             $scope.names = response.data;
        });
}
    
// fetching all  records based on id that has to be updated
$scope.edit=function(){
    if(isNaN(parseInt($scope.editid)))
        {
            alert("ID must be number");
             $scope.id="";
        }
        var ids ={ 
            id:$scope.editid
        } 
        $http.post('http://localhost:4000/edit',ids)
                .then(function(data) {
                    if(data.data.length==0){
                        alert("ID doesn't exists");
                    }
                    else{
                        $scope.result = data;
                        $scope.editusername=data.data['0'].name;
                        $scope.editpassword=data.data['0'].password;
                        $scope.updateid=data.data['0'].id;
                    }
                })
}

// updating the username and password based on id
$scope.update=function(){
            var updatedata ={ 
                    name:$scope.editusername,
                    password:$scope.editpassword,
                    id:$scope.updateid
                } 
    $http.put('http://localhost:4000/update',updatedata)
    .then(function(data, status, headers, config) {
            $scope.result = data;
            console.log("updated successfully")
                $http.get('http://localhost:4000/alldata')
                .then(function (response) {$scope.feilds = response.data;
                    console.log($scope.feilds);
                });
    })
}



// registration of new user
$scope.submit = function() {
    var datas ={
            name:$scope.name, 
            id:$scope.id,
            password:$scope.password,
            gender:$scope.gender,
            country:$scope.countryName,
            state:$scope.stateName,
            city:$scope.cityName,
            hobbies:$scope.hobbiesName,
            dob:$filter('date')($scope.dob, 'yyyy-MM-dd')
        } 
    if($scope.name=="" || $scope.name==undefined || $scope.id=="" || $scope.id==undefined || $scope.password=="" || $scope.password==undefined || $scope.gender=="" || $scope.gender==undefined || $scope.countryName=="" || $scope.countryName==undefined || $scope.stateName=="" || $scope.stateName==undefined || $scope.cityName=="" || $scope.cityName==undefined || $scope.hobbiesName=="" || $scope.hobbiesName==undefined || $scope.dob=="" || $scope.dob==undefined)
        {
            alert("MUST FILL ALL THE FEILDS");       
        }
    else{
        $http.post('http://localhost:4000/register', datas)
            .then(function(data, status, headers, config) {
                $scope.result = data;
                console.log("inserted successfully")
            })
        };
    $http.get('http://localhost:4000/alldata')
    .then(function (response) {$scope.feilds = response.data;
    });
    }
});



